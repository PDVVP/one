#1

print ("Implemention of Tokenization")
import nltk
nltk.download('punkt')

text ="""Welcome you to programming knowldge. Lets start with our first tutorial in NLTK. We shall learn basic Nltk here"""

#from nltk.tokenize import word_tokenize
#print(word_tokenize(text))
 
from nltk.tokenize import sent_tokenize
print(sent_tokenize(text))




#2


print("Stop Word finding")

import nltk
nltk.download('stopwords')
text="""Welcome you to programming knowldge. Lets start with our first tutorial in NLTK. We shall learn basic Nltk here"""

from nltk.corpus import stopwords

stop_words = stopwords.words('english')

from nltk.tokenize import word_tokenize,sent_tokenize

token = word_tokenize(text)

cleaned_token =[]
for word in token:
    if word not in stop_words:
        cleaned_token.append(word)

print("This is unclean",token)
print("this is clean",cleaned_token)


#3

print(" Speech Tagging")

import nltk

nltk.download('averaged_perceptron_tagger')
from nltk import pos_tag

text = "Welcome you to programming knowldge. Lets start with our first tutorial in NLTK. We shall learn basic Nltk here"

print("After Split",text)

tokens_tag = pos_tag(text)
print("After Tokenization",tokens_tag)




#4


print("Count Word")
import nltk
from nltk.corpus import webtext
from nltk.probability import FreqDist

nltk.download('webtext')
wt_words = webtext.words('testing.txt')
data_analysis = nltk.FreqDist(wt_words)
filter_word = dict([(m,n) for m,n in data_analysis.items() if len(m)>3])
for key in sorted(filter_word):
    print("%s %s" % (key,filter_word[key]))
data_analysis = nltk.FreqDist(filter_word)
